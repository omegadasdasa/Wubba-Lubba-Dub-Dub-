# User Database Dictionary
# Structure: {user_id: {'id': str, 'password': str, 'role': str}}

users = {
    '123456789012': {
        'id': '123456789012',
        'password': 'admin_password_123',
        'role': 'admin'
    },
    '234567890123': {
        'id': '234567890123',
        'password': 'moderator_pass_456',
        'role': 'moderator'
    },
    '345678901234': {
        'id': '345678901234',
        'password': 'user_password_789',
        'role': 'user'
    }
}


# ============ INSERT/ADD USER ============
def insert_user(user_id, password, role):
    """
    Insert a new user into the dictionary
    
    Args:
        user_id (str): 12-digit user ID
        password (str): User password
        role (str): User role (admin, moderator, user)
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    # Validate user_id format
    if not isinstance(user_id, str) or len(user_id) != 12 or not user_id.isdigit():
        return {'success': False, 'message': 'User ID must be 12 digits'}
    
    # Check if user already exists
    if user_id in users:
        return {'success': False, 'message': 'User ID already exists'}
    
    # Validate role
    valid_roles = ['admin', 'moderator', 'user']
    if role not in valid_roles:
        return {'success': False, 'message': f'Role must be one of: {", ".join(valid_roles)}'}
    
    # Validate password
    if not password or len(password) < 4:
        return {'success': False, 'message': 'Password must be at least 4 characters'}
    
    # Insert user
    users[user_id] = {
        'id': user_id,
        'password': password,
        'role': role
    }
    return {'success': True, 'message': f'User {user_id} inserted successfully'}


# ============ AUTHENTICATION ============
def authenticate_user(user_id, password):
    """
    Authenticate a user by ID and password
    
    Args:
        user_id (str): 12-digit user ID
        password (str): User password
    
    Returns:
        dict: {'authenticated': bool, 'message': str, 'user': dict or None}
    """
    if user_id not in users:
        return {'authenticated': False, 'message': 'User ID not found', 'user': None}
    
    user = users[user_id]
    if user['password'] == password:
        return {
            'authenticated': True,
            'message': 'Authentication successful',
            'user': {'id': user['id'], 'role': user['role']}
        }
    else:
        return {'authenticated': False, 'message': 'Invalid password', 'user': None}


# ============ REMOVE USER ============
def remove_user(user_id):
    """
    Remove a user from the dictionary
    
    Args:
        user_id (str): 12-digit user ID to remove
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    if user_id not in users:
        return {'success': False, 'message': f'User {user_id} not found'}
    
    del users[user_id]
    return {'success': True, 'message': f'User {user_id} removed successfully'}


# ============ UTILITY FUNCTIONS ============
def get_user(user_id):
    """Retrieve a user by ID (without password)"""
    if user_id not in users:
        return None
    user = users[user_id].copy()
    user.pop('password')  # Don't return password
    return user


def get_all_users():
    """Get all users (without passwords)"""
    all_users = {}
    for user_id, user_data in users.items():
        user_copy = user_data.copy()
        user_copy.pop('password')
        all_users[user_id] = user_copy
    return all_users


def user_exists(user_id):
    """Check if a user exists"""
    return user_id in users


def get_users_by_role(role):
    """Get all users with a specific role"""
    return {uid: user for uid, user in users.items() if user['role'] == role}
